package com.pressfran.cobranzas;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DbHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "pressfran.db";
    private static final int DB_VERSION = 4;

    public DbHelper(Context context) { super(context, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) { createSchema(db); }

    private void createSchema(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS customers (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT NOT NULL," +
                "dni TEXT DEFAULT ''," +
                "phone TEXT NOT NULL," +
                "business TEXT DEFAULT ''," +
                "address TEXT DEFAULT ''," +
                "guarantor TEXT DEFAULT ''," +
                "notes TEXT DEFAULT ''," +
                "active INTEGER NOT NULL DEFAULT 1," +
                "sms_enabled INTEGER NOT NULL DEFAULT 0," +
                "created_date TEXT DEFAULT '')");

        db.execSQL("CREATE TABLE IF NOT EXISTS loans (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "client_id INTEGER NOT NULL," +
                "type TEXT NOT NULL DEFAULT 'PRÉSTAMO'," +
                "principal REAL NOT NULL DEFAULT 0," +
                "total_financed REAL NOT NULL DEFAULT 0," +
                "balance REAL NOT NULL DEFAULT 0," +
                "installment REAL NOT NULL DEFAULT 0," +
                "installment_count INTEGER NOT NULL DEFAULT 1," +
                "paid_installments INTEGER NOT NULL DEFAULT 0," +
                "current_installment_paid REAL NOT NULL DEFAULT 0," +
                "frequency TEXT NOT NULL DEFAULT 'Semanal'," +
                "period_interest REAL NOT NULL DEFAULT 10," +
                "due_date TEXT NOT NULL," +
                "daily_interest REAL NOT NULL DEFAULT 3," +
                "grace_days INTEGER NOT NULL DEFAULT 3," +
                "commitment_date TEXT DEFAULT ''," +
                "commitment_amount REAL NOT NULL DEFAULT 0," +
                "status TEXT NOT NULL DEFAULT 'ACTIVO'," +
                "notes TEXT DEFAULT ''," +
                "created_date TEXT DEFAULT ''," +
                "FOREIGN KEY(client_id) REFERENCES customers(id))");

        db.execSQL("CREATE TABLE IF NOT EXISTS payments (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "loan_id INTEGER NOT NULL," +
                "debt_amount REAL NOT NULL DEFAULT 0," +
                "mora_amount REAL NOT NULL DEFAULT 0," +
                "total_received REAL NOT NULL DEFAULT 0," +
                "payment_date TEXT NOT NULL," +
                "method TEXT NOT NULL DEFAULT 'Efectivo'," +
                "note TEXT DEFAULT ''," +
                "FOREIGN KEY(loan_id) REFERENCES loans(id))");

        db.execSQL("CREATE TABLE IF NOT EXISTS sms_logs (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "loan_id INTEGER NOT NULL," +
                "client_id INTEGER NOT NULL," +
                "event_key TEXT NOT NULL," +
                "event_type TEXT NOT NULL," +
                "phone TEXT NOT NULL," +
                "message TEXT NOT NULL," +
                "sent_at TEXT NOT NULL," +
                "status TEXT NOT NULL DEFAULT 'PENDIENTE'," +
                "detail TEXT DEFAULT ''," +
                "UNIQUE(loan_id,event_key))");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 3) migrateLegacy(db);
        if (oldVersion < 4) {
            if (!columnExists(db,"customers","sms_enabled"))
                db.execSQL("ALTER TABLE customers ADD COLUMN sms_enabled INTEGER NOT NULL DEFAULT 0");
            db.execSQL("CREATE TABLE IF NOT EXISTS sms_logs (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "loan_id INTEGER NOT NULL," +
                    "client_id INTEGER NOT NULL," +
                    "event_key TEXT NOT NULL," +
                    "event_type TEXT NOT NULL," +
                    "phone TEXT NOT NULL," +
                    "message TEXT NOT NULL," +
                    "sent_at TEXT NOT NULL," +
                    "status TEXT NOT NULL DEFAULT 'PENDIENTE'," +
                    "detail TEXT DEFAULT ''," +
                    "UNIQUE(loan_id,event_key))");
        }
    }

    private void migrateLegacy(SQLiteDatabase db) {
        db.beginTransaction();
        try {
            if (tableExists(db, "clients")) db.execSQL("ALTER TABLE clients RENAME TO legacy_clients");
            if (tableExists(db, "payments")) db.execSQL("ALTER TABLE payments RENAME TO legacy_payments");
            createSchema(db);

            Map<Long, Long> oldClientToNewLoan = new HashMap<>();
            if (tableExists(db, "legacy_clients")) {
                Cursor c = db.rawQuery("SELECT * FROM legacy_clients", null);
                while (c.moveToNext()) {
                    long oldId = longCol(c, "id", 0);
                    String name = strCol(c, "name", "Cliente");
                    String phone = strCol(c, "phone", "");
                    ContentValues cv = new ContentValues();
                    cv.put("name", name); cv.put("dni", strCol(c,"dni","")); cv.put("phone", phone);
                    cv.put("business", strCol(c,"business","")); cv.put("address", strCol(c,"address",""));
                    cv.put("guarantor", strCol(c,"guarantor","")); cv.put("notes", strCol(c,"notes",""));
                    cv.put("active", 1); cv.put("sms_enabled",0); cv.put("created_date", strCol(c,"created_date", LocalDate.now().toString()));
                    long newClientId = db.insert("customers", null, cv);

                    double balance = dblCol(c,"balance",0);
                    double installment = dblCol(c,"installment", balance);
                    double principal = dblCol(c,"original_amount", balance);
                    double total = dblCol(c,"total_financed", Math.max(balance, principal));
                    int count = intCol(c,"installment_count",1);
                    int paid = intCol(c,"paid_installments",0);
                    ContentValues lv = new ContentValues();
                    lv.put("client_id", newClientId); lv.put("type", "PRÉSTAMO");
                    lv.put("principal", principal); lv.put("total_financed", total); lv.put("balance", balance);
                    lv.put("installment", installment); lv.put("installment_count", count); lv.put("paid_installments", paid);
                    lv.put("current_installment_paid",0); lv.put("frequency",strCol(c,"frequency","Semanal"));
                    lv.put("period_interest",dblCol(c,"period_interest",10)); lv.put("due_date",strCol(c,"due_date",LocalDate.now().toString()));
                    lv.put("daily_interest",dblCol(c,"daily_interest",3)); lv.put("grace_days",3);
                    lv.put("commitment_date",strCol(c,"commitment_date","")); lv.put("commitment_amount",0);
                    lv.put("status",strCol(c,"status","ACTIVO")); lv.put("notes",strCol(c,"notes",""));
                    lv.put("created_date",strCol(c,"created_date",LocalDate.now().toString()));
                    long newLoanId = db.insert("loans", null, lv);
                    oldClientToNewLoan.put(oldId, newLoanId);
                }
                c.close();
            }

            if (tableExists(db, "legacy_payments")) {
                Cursor p = db.rawQuery("SELECT * FROM legacy_payments", null);
                while (p.moveToNext()) {
                    long oldClientId = longCol(p,"client_id",0);
                    Long loanId = oldClientToNewLoan.get(oldClientId);
                    if (loanId == null) continue;
                    double a = dblCol(p,"amount",0);
                    ContentValues pv = new ContentValues();
                    pv.put("loan_id", loanId); pv.put("debt_amount", a); pv.put("mora_amount",0);
                    pv.put("total_received",a); pv.put("payment_date",strCol(p,"payment_date",LocalDate.now().toString()));
                    pv.put("method","Sin especificar"); pv.put("note",strCol(p,"note",""));
                    db.insert("payments", null, pv);
                }
                p.close();
            }
            db.execSQL("DROP TABLE IF EXISTS legacy_clients");
            db.execSQL("DROP TABLE IF EXISTS legacy_payments");
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    private boolean tableExists(SQLiteDatabase db, String name) {
        Cursor c = db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name=?", new String[]{name});
        boolean ok = c.moveToFirst(); c.close(); return ok;
    }
    private boolean columnExists(SQLiteDatabase db,String table,String column){
        Cursor c=db.rawQuery("PRAGMA table_info("+table+")",null);boolean ok=false;
        while(c.moveToNext())if(column.equals(c.getString(c.getColumnIndexOrThrow("name")))){ok=true;break;}
        c.close();return ok;
    }
    private int idx(Cursor c,String col){ return c.getColumnIndex(col); }
    private String strCol(Cursor c,String col,String def){ int i=idx(c,col); return i<0||c.isNull(i)?def:c.getString(i); }
    private double dblCol(Cursor c,String col,double def){ int i=idx(c,col); return i<0||c.isNull(i)?def:c.getDouble(i); }
    private int intCol(Cursor c,String col,int def){ int i=idx(c,col); return i<0||c.isNull(i)?def:c.getInt(i); }
    private long longCol(Cursor c,String col,long def){ int i=idx(c,col); return i<0||c.isNull(i)?def:c.getLong(i); }

    public long addCustomer(String name, String dni, String phone, String business, String address,
                            String guarantor, String notes, boolean smsEnabled) {
        ContentValues v = new ContentValues();
        v.put("name",name); v.put("dni",dni); v.put("phone",phone); v.put("business",business);
        v.put("address",address); v.put("guarantor",guarantor); v.put("notes",notes);
        v.put("active",1); v.put("sms_enabled",smsEnabled?1:0); v.put("created_date",LocalDate.now().toString());
        return getWritableDatabase().insert("customers",null,v);
    }

    public void updateCustomer(long id, String name, String dni, String phone, String business,
                               String address, String guarantor, String notes, boolean smsEnabled) {
        ContentValues v = new ContentValues();
        v.put("name",name); v.put("dni",dni); v.put("phone",phone); v.put("business",business);
        v.put("address",address); v.put("guarantor",guarantor); v.put("notes",notes); v.put("sms_enabled",smsEnabled?1:0);
        getWritableDatabase().update("customers",v,"id=?",new String[]{String.valueOf(id)});
    }

    public long addLoan(long clientId, String type, double principal, double totalFinanced,
                        double installment, int installmentCount, String frequency,
                        double periodInterest, String dueDate, double dailyInterest,
                        int graceDays, String notes) {
        ContentValues v = new ContentValues();
        v.put("client_id",clientId); v.put("type",type); v.put("principal",principal);
        v.put("total_financed",totalFinanced); v.put("balance",totalFinanced); v.put("installment",installment);
        v.put("installment_count",installmentCount); v.put("paid_installments",0); v.put("current_installment_paid",0);
        v.put("frequency",frequency); v.put("period_interest",periodInterest); v.put("due_date",dueDate);
        v.put("daily_interest",dailyInterest); v.put("grace_days",graceDays); v.put("commitment_date","");
        v.put("commitment_amount",0); v.put("status","ACTIVO"); v.put("notes",notes);
        v.put("created_date",LocalDate.now().toString());
        return getWritableDatabase().insert("loans",null,v);
    }

    public List<Client> getCustomers() {
        List<Client> out = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery("SELECT id,name,dni,phone,business,address,guarantor,notes,active,sms_enabled,created_date FROM customers ORDER BY name COLLATE NOCASE",null);
        while(c.moveToNext()) out.add(clientFromCursor(c)); c.close(); return out;
    }

    public Client getCustomer(long id) {
        Cursor c = getReadableDatabase().rawQuery("SELECT id,name,dni,phone,business,address,guarantor,notes,active,sms_enabled,created_date FROM customers WHERE id=?",new String[]{String.valueOf(id)});
        Client x = c.moveToFirst()?clientFromCursor(c):null; c.close(); return x;
    }

    private Client clientFromCursor(Cursor c){ return new Client(c.getLong(0),safe(c,1),safe(c,2),safe(c,3),safe(c,4),safe(c,5),safe(c,6),safe(c,7),c.getInt(8)==1,c.getInt(9)==1,safe(c,10)); }

    public List<Loan> getLoansForCustomer(long clientId) {
        List<Loan> out=new ArrayList<>();
        Cursor c=getReadableDatabase().rawQuery("SELECT id,client_id,type,principal,total_financed,balance,installment,installment_count,paid_installments,current_installment_paid,frequency,period_interest,due_date,daily_interest,grace_days,commitment_date,commitment_amount,status,notes,created_date FROM loans WHERE client_id=? ORDER BY id DESC",new String[]{String.valueOf(clientId)});
        while(c.moveToNext()) out.add(loanFromCursor(c)); c.close(); return out;
    }

    public List<Loan> getActiveLoans() {
        List<Loan> out=new ArrayList<>();
        Cursor c=getReadableDatabase().rawQuery("SELECT id,client_id,type,principal,total_financed,balance,installment,installment_count,paid_installments,current_installment_paid,frequency,period_interest,due_date,daily_interest,grace_days,commitment_date,commitment_amount,status,notes,created_date FROM loans WHERE status='ACTIVO' ORDER BY due_date ASC",null);
        while(c.moveToNext()) out.add(loanFromCursor(c)); c.close(); return out;
    }

    public Loan getLoan(long id) {
        Cursor c=getReadableDatabase().rawQuery("SELECT id,client_id,type,principal,total_financed,balance,installment,installment_count,paid_installments,current_installment_paid,frequency,period_interest,due_date,daily_interest,grace_days,commitment_date,commitment_amount,status,notes,created_date FROM loans WHERE id=?",new String[]{String.valueOf(id)});
        Loan x=c.moveToFirst()?loanFromCursor(c):null;c.close();return x;
    }

    private Loan loanFromCursor(Cursor c){return new Loan(c.getLong(0),c.getLong(1),safe(c,2),c.getDouble(3),c.getDouble(4),c.getDouble(5),c.getDouble(6),c.getInt(7),c.getInt(8),c.getDouble(9),safe(c,10),c.getDouble(11),safe(c,12),c.getDouble(13),c.getInt(14),safe(c,15),c.getDouble(16),safe(c,17),safe(c,18),safe(c,19));}
    private String safe(Cursor c,int i){return c.isNull(i)?"":c.getString(i);}

    public double customerBalance(long clientId){ Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(balance),0) FROM loans WHERE client_id=? AND status='ACTIVO'",new String[]{String.valueOf(clientId)}); double x=c.moveToFirst()?c.getDouble(0):0;c.close();return x; }
    public int customerActiveLoans(long clientId){ Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM loans WHERE client_id=? AND status='ACTIVO'",new String[]{String.valueOf(clientId)}); int x=c.moveToFirst()?c.getInt(0):0;c.close();return x; }

    public void setCommitment(long loanId,String date,double amount){ ContentValues v=new ContentValues();v.put("commitment_date",date);v.put("commitment_amount",amount);getWritableDatabase().update("loans",v,"id=?",new String[]{String.valueOf(loanId)}); }

    public void markRefinanced(long loanId){ ContentValues v=new ContentValues();v.put("status","REFINANCIADO");v.put("commitment_date","");v.put("commitment_amount",0);getWritableDatabase().update("loans",v,"id=?",new String[]{String.valueOf(loanId)}); }

    public void registerPayment(Loan loan,double debtAmount,double moraAmount,String method,String note){
        if(debtAmount<0||moraAmount<0||(debtAmount+moraAmount)<=0)return;
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try{
            double applied=Math.min(debtAmount,loan.balance); double totalReceived=applied+moraAmount;
            ContentValues p=new ContentValues();p.put("loan_id",loan.id);p.put("debt_amount",applied);p.put("mora_amount",moraAmount);p.put("total_received",totalReceived);p.put("payment_date",LocalDate.now().toString());p.put("method",method);p.put("note",note);db.insert("payments",null,p);

            double newBalance=Math.max(0,loan.balance-applied);
            double credited=loan.currentInstallmentPaid+applied;
            int paidCount=loan.paidInstallments;
            LocalDate next=LocalDate.parse(loan.dueDate);
            while(credited+0.01>=loan.installment && paidCount<loan.installmentCount && loan.installment>0){ credited-=loan.installment; paidCount++; next=nextDate(next,loan.frequency); }
            if(newBalance<=0.01){credited=0;paidCount=loan.installmentCount;}
            ContentValues v=new ContentValues();v.put("balance",newBalance);v.put("current_installment_paid",credited);v.put("paid_installments",paidCount);v.put("due_date",next.toString());v.put("commitment_date","");v.put("commitment_amount",0);if(newBalance<=0.01)v.put("status","PAGADO");db.update("loans",v,"id=?",new String[]{String.valueOf(loan.id)});
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
    }

    private LocalDate nextDate(LocalDate d,String frequency){ if("Quincenal".equalsIgnoreCase(frequency))return d.plusDays(15);if("Mensual".equalsIgnoreCase(frequency))return d.plusMonths(1);return d.plusWeeks(1); }

    public List<String> getPaymentHistory(long loanId){
        List<String> out=new ArrayList<>();Cursor c=getReadableDatabase().rawQuery("SELECT payment_date,debt_amount,mora_amount,total_received,method,note FROM payments WHERE loan_id=? ORDER BY id DESC",new String[]{String.valueOf(loanId)});
        while(c.moveToNext()){
            String row=prettyDate(c.getString(0))+" · "+c.getString(4)+" · Total "+MessageBuilder.money(c.getDouble(3));
            if(c.getDouble(1)>0)row+="\nAplicado a deuda: "+MessageBuilder.money(c.getDouble(1));
            if(c.getDouble(2)>0)row+=" · Mora: "+MessageBuilder.money(c.getDouble(2));
            String note=c.isNull(5)?"":c.getString(5);if(!note.trim().isEmpty())row+="\n"+note;out.add(row);
        }c.close();return out;
    }
    public boolean wasSmsSent(long loanId,String eventKey){
        Cursor c=getReadableDatabase().rawQuery("SELECT status FROM sms_logs WHERE loan_id=? AND event_key=? LIMIT 1",
                new String[]{String.valueOf(loanId),eventKey});
        boolean exists=c.moveToFirst();c.close();return exists;
    }

    public long logSmsAttempt(long loanId,long clientId,String eventKey,String eventType,String phone,String message){
        ContentValues v=new ContentValues();
        v.put("loan_id",loanId);v.put("client_id",clientId);v.put("event_key",eventKey);v.put("event_type",eventType);
        v.put("phone",phone);v.put("message",message);v.put("sent_at",java.time.LocalDateTime.now().toString());
        v.put("status","PENDIENTE");v.put("detail","");
        return getWritableDatabase().insertWithOnConflict("sms_logs",null,v,SQLiteDatabase.CONFLICT_IGNORE);
    }

    public void updateSmsStatus(long logId,String status,String detail){
        if(logId<=0)return;ContentValues v=new ContentValues();v.put("status",status);v.put("detail",detail==null?"":detail);
        getWritableDatabase().update("sms_logs",v,"id=?",new String[]{String.valueOf(logId)});
    }

    public List<String> getSmsHistory(long loanId){
        List<String> out=new ArrayList<>();
        Cursor c=getReadableDatabase().rawQuery("SELECT sent_at,event_type,phone,status,detail FROM sms_logs WHERE loan_id=? ORDER BY id DESC LIMIT 50",
                new String[]{String.valueOf(loanId)});
        while(c.moveToNext()){
            String when=c.getString(0);if(when!=null&&when.length()>=16)when=when.substring(0,16).replace("T"," ");
            String row=when+" · "+c.getString(1)+" · "+c.getString(3)+"\n"+c.getString(2);
            String d=c.isNull(4)?"":c.getString(4);if(!d.trim().isEmpty())row+=" · "+d;out.add(row);
        }c.close();return out;
    }

    private String prettyDate(String iso){try{LocalDate d=LocalDate.parse(iso);return String.format("%02d/%02d/%04d",d.getDayOfMonth(),d.getMonthValue(),d.getYear());}catch(Exception e){return iso;}}
}
