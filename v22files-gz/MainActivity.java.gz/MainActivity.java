package com.pressfran.cobranzas;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.AlarmManager;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private DbHelper db;
    private LinearLayout root, summaryPanel, collectionPanel, loanPanel, customersPanel;
    private LinearLayout collectionList, customersList;
    private TextView dashboard, planPreview, collectionTitle;
    private EditText searchCustomer, aliasInput, moraDefaultInput, graceDefaultInput, smsHourInput;
    private EditText name, dni, phone, business, address, guarantor, customerNotes;
    private CheckBox smsGlobal, smsPreDue, smsDue, smsMora, smsCommitment, clientSms;
    private TextView smsStatus;
    private EditText amount, count, rate, installment, due, loanNotes, moraLoan, graceLoan;
    private Spinner customerSelector, frequency, loanType;
    private List<Client> customerCache = new ArrayList<>();
    private long selectedClientId = 0;
    private long pendingRefinanceLoanId = 0;
    private String collectionFilter = "HOY";

    private final int green=Color.rgb(11,79,60), gold=Color.rgb(212,175,55), bg=Color.rgb(244,246,245), red=Color.rgb(165,35,35), amber=Color.rgb(175,105,0);

    @Override public void onCreate(Bundle b){
        super.onCreate(b);db=new DbHelper(this);buildUi();requestNotifications();ReminderScheduler.scheduleDaily(this);refreshAll();showPanel(summaryPanel);updateSmsStatusText();
    }

    @Override protected void onResume(){
        super.onResume();
        ReminderScheduler.scheduleDaily(this);
        updateSmsStatusText();
    }

    private void buildUi(){
        LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setBackgroundColor(bg);
        TextView brand=text("PRESSFRAN",28,Typeface.BOLD);brand.setTextColor(green);brand.setGravity(Gravity.CENTER);brand.setPadding(0,dp(12),0,0);outer.addView(brand,new LinearLayout.LayoutParams(-1,dp(48)));
        TextView subtitle=text("Gestión de préstamos y cobranzas",13,Typeface.NORMAL);subtitle.setGravity(Gravity.CENTER);outer.addView(subtitle,new LinearLayout.LayoutParams(-1,dp(28)));

        HorizontalScrollView navScroll=new HorizontalScrollView(this);navScroll.setHorizontalScrollBarEnabled(false);LinearLayout nav=new LinearLayout(this);nav.setOrientation(LinearLayout.HORIZONTAL);nav.setPadding(dp(6),0,dp(6),dp(4));navScroll.addView(nav);
        Button bInicio=navButton("Inicio"),bCobrar=navButton("Cobrar"),bNuevo=navButton("Nuevo préstamo"),bClientes=navButton("Clientes");nav.addView(bInicio);nav.addView(bCobrar);nav.addView(bNuevo);nav.addView(bClientes);outer.addView(navScroll,new LinearLayout.LayoutParams(-1,dp(52)));

        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(12),dp(4),dp(12),dp(28));scroll.addView(root);
        summaryPanel=buildSummary();collectionPanel=buildCollections();loanPanel=buildLoanForm();customersPanel=buildCustomers();root.addView(summaryPanel);root.addView(collectionPanel);root.addView(loanPanel);root.addView(customersPanel);outer.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(outer);

        bInicio.setOnClickListener(v->{refreshAll();showPanel(summaryPanel);});
        bCobrar.setOnClickListener(v->{collectionFilter="HOY";refreshCollections();showPanel(collectionPanel);});
        bNuevo.setOnClickListener(v->{prepareNewLoan(null,null);showPanel(loanPanel);});
        bClientes.setOnClickListener(v->{refreshCustomers();showPanel(customersPanel);});
    }

    private LinearLayout buildSummary(){
        LinearLayout p=panel();p.addView(section("Resumen de cartera"));dashboard=text("",16,Typeface.BOLD);dashboard.setBackgroundColor(Color.WHITE);dashboard.setPadding(dp(14),dp(14),dp(14),dp(14));p.addView(dashboard);
        LinearLayout quick=new LinearLayout(this);quick.setOrientation(LinearLayout.HORIZONTAL);Button cobrar=primary("Cobrar hoy"),nuevo=primary("Nuevo préstamo");quick.addView(cobrar,weight48());quick.addView(nuevo,weight48());p.addView(quick,margins(-1,dp(50),0,10,0,8));cobrar.setOnClickListener(v->{collectionFilter="HOY";refreshCollections();showPanel(collectionPanel);});nuevo.setOnClickListener(v->{prepareNewLoan(null,null);showPanel(loanPanel);});

        p.addView(section("Configuración financiera"));aliasInput=input("Alias de transferencia",false);moraDefaultInput=input("Mora diaria por defecto (%)",true);graceDefaultInput=input("Días de gracia por defecto",true);
        android.content.SharedPreferences sp=getSharedPreferences("settings",MODE_PRIVATE);aliasInput.setText(sp.getString("alias",""));moraDefaultInput.setText(trim(sp.getFloat("default_interest",3f)));graceDefaultInput.setText(String.valueOf(sp.getInt("default_grace",3)));p.addView(aliasInput);p.addView(moraDefaultInput);p.addView(graceDefaultInput);

        p.addView(section("SMS automáticos"));
        smsGlobal=new CheckBox(this);smsGlobal.setText("Activar envío automático de SMS");smsGlobal.setChecked(sp.getBoolean("sms_auto_enabled",false));p.addView(smsGlobal);
        smsHourInput=input("Hora diaria de envío (0 a 23)",true);smsHourInput.setText(String.valueOf(sp.getInt("sms_hour",8)));p.addView(smsHourInput);
        smsPreDue=new CheckBox(this);smsPreDue.setText("Avisar 1 día antes del vencimiento");smsPreDue.setChecked(sp.getBoolean("sms_pre_due",true));p.addView(smsPreDue);
        smsDue=new CheckBox(this);smsDue.setText("Avisar el día del vencimiento");smsDue.setChecked(sp.getBoolean("sms_due",true));p.addView(smsDue);
        smsMora=new CheckBox(this);smsMora.setText("Avisar cada día con mora");smsMora.setChecked(sp.getBoolean("sms_mora",true));p.addView(smsMora);
        smsCommitment=new CheckBox(this);smsCommitment.setText("Recordar compromisos de pago");smsCommitment.setChecked(sp.getBoolean("sms_commitment",true));p.addView(smsCommitment);
        smsStatus=text("",13,Typeface.BOLD);smsStatus.setPadding(dp(4),dp(6),dp(4),dp(6));p.addView(smsStatus);

        LinearLayout authRow=new LinearLayout(this);authRow.setOrientation(LinearLayout.HORIZONTAL);
        Button auth=secondary("Autorizar SMS"),run=secondary("Ejecutar ahora");authRow.addView(auth,weight44());authRow.addView(run,weight44());p.addView(authRow);
        auth.setOnClickListener(v->requestAutomationPermissions());
        run.setOnClickListener(v->{sendBroadcast(new Intent(this,ReminderReceiver.class));toast("Automatización ejecutada");});

        Button save=primary("Guardar configuración");save.setOnClickListener(v->{
            int g=Math.max(0,(int)num(graceDefaultInput,3));
            int h=Math.max(0,Math.min(23,(int)num(smsHourInput,8)));
            getSharedPreferences("settings",MODE_PRIVATE).edit()
                    .putString("alias",aliasInput.getText().toString().trim())
                    .putFloat("default_interest",(float)num(moraDefaultInput,3))
                    .putInt("default_grace",g)
                    .putBoolean("sms_auto_enabled",smsGlobal.isChecked())
                    .putInt("sms_hour",h).putInt("sms_minute",0)
                    .putBoolean("sms_pre_due",smsPreDue.isChecked())
                    .putBoolean("sms_due",smsDue.isChecked())
                    .putBoolean("sms_mora",smsMora.isChecked())
                    .putBoolean("sms_commitment",smsCommitment.isChecked()).apply();
            ReminderScheduler.scheduleDaily(this);
            if(smsGlobal.isChecked())requestAutomationPermissions();
            updateSmsStatusText();toast("Configuración guardada");
        });p.addView(save);
        TextView hint=text("La app no repite el mismo aviso de vencimiento. La mora puede generar un aviso nuevo cada día. Cada envío queda registrado en el historial.",13,Typeface.NORMAL);hint.setPadding(0,dp(8),0,0);p.addView(hint);return p;
    }

    private LinearLayout buildCollections(){
        LinearLayout p=panel();collectionTitle=section("Cobranza de hoy");p.addView(collectionTitle);
        HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);LinearLayout filters=new LinearLayout(this);filters.setOrientation(LinearLayout.HORIZONTAL);String[] fs={"Hoy","Atrasados","Compromisos","Todos"};String[] keys={"HOY","ATRASADOS","COMPROMISOS","TODOS"};for(int i=0;i<fs.length;i++){Button b=chip(fs[i]);final String k=keys[i];b.setOnClickListener(v->{collectionFilter=k;refreshCollections();});filters.addView(b);}hs.addView(filters);p.addView(hs,new LinearLayout.LayoutParams(-1,dp(50)));
        collectionList=new LinearLayout(this);collectionList.setOrientation(LinearLayout.VERTICAL);p.addView(collectionList);return p;
    }

    private LinearLayout buildLoanForm(){
        LinearLayout p=panel();p.addView(section("Cliente"));
        customerSelector=new Spinner(this);p.addView(label("Seleccionar cliente existente o cargar uno nuevo"));p.addView(customerSelector,margins(-1,dp(52),0,0,0,8));customerSelector.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onNothingSelected(AdapterView<?> a){}public void onItemSelected(AdapterView<?> a,View v,int pos,long id){if(pos==0){selectedClientId=0;enableClientFields(true);if(pendingRefinanceLoanId==0)clearClientFields();}else if(pos-1<customerCache.size()){Client c=customerCache.get(pos-1);selectedClientId=c.id;fillClientFields(c);enableClientFields(true);}}});
        name=input("Nombre y apellido *",false);dni=input("DNI",false);phone=input("Celular con código país *",false);phone.setInputType(InputType.TYPE_CLASS_PHONE);business=input("Comercio / emprendimiento",false);address=input("Domicilio / localidad",false);guarantor=input("Garante",false);customerNotes=input("Observaciones del cliente",false);p.addView(name);p.addView(dni);p.addView(phone);clientSms=new CheckBox(this);clientSms.setText("Cliente autoriza recordatorios SMS automáticos");p.addView(clientSms);p.addView(business);p.addView(address);p.addView(guarantor);p.addView(customerNotes);

        p.addView(section("Préstamo"));loanType=spinner(new String[]{"Préstamo","Renovación","Refinanciación"});p.addView(label("Tipo de operación"));p.addView(loanType,margins(-1,dp(50),0,0,0,8));amount=input("Monto entregado / refinanciado en $ *",true);p.addView(amount);p.addView(label("Montos rápidos"));p.addView(amountQuickRow());
        count=input("Cantidad de cuotas *",true);rate=input("Interés por período (%)",true);p.addView(count);p.addView(countQuickRow());p.addView(rate);
        frequency=spinner(new String[]{"Semanal","Quincenal","Mensual"});p.addView(label("Frecuencia"));p.addView(frequency,margins(-1,dp(50),0,0,0,8));
        installment=input("Valor de cada cuota en $",true);due=input("Primer vencimiento",false);due.setFocusable(false);due.setClickable(true);due.setOnClickListener(v->pickDate(due));moraLoan=input("Mora diaria (%)",true);graceLoan=input("Días de gracia",true);loanNotes=input("Observaciones del préstamo",false);p.addView(installment);p.addView(due);p.addView(moraLoan);p.addView(graceLoan);p.addView(loanNotes);
        Button calc=secondary("Calcular plan");calc.setOnClickListener(v->calculatePlan());p.addView(calc);
        planPreview=text("",15,Typeface.BOLD);planPreview.setBackgroundColor(Color.WHITE);planPreview.setPadding(dp(12),dp(12),dp(12),dp(12));p.addView(planPreview,margins(-1,-2,0,8,0,10));
        Button save=primary("Guardar préstamo");save.setOnClickListener(v->saveLoan());p.addView(save);return p;
    }

    private LinearLayout buildCustomers(){
        LinearLayout p=panel();p.addView(section("Clientes"));searchCustomer=input("Buscar por nombre, comercio, DNI o teléfono",false);p.addView(searchCustomer);searchCustomer.addTextChangedListener(new SimpleWatcher(){@Override public void changed(){refreshCustomers();}});customersList=new LinearLayout(this);customersList.setOrientation(LinearLayout.VERTICAL);p.addView(customersList);return p;
    }

    private LinearLayout amountQuickRow(){HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);int[] vals={100000,200000,300000,400000,500000};for(int v:vals){Button b=chip(MessageBuilder.money(v));b.setOnClickListener(x->{amount.setText(String.valueOf(v));calculatePlan();});row.addView(b);}hs.addView(row);LinearLayout wrap=new LinearLayout(this);wrap.addView(hs,new LinearLayout.LayoutParams(-1,dp(48)));return wrap;}
    private LinearLayout countQuickRow(){HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);for(int v=1;v<=6;v++){Button b=chip(v+" cuota"+(v==1?"":"s"));final int x=v;b.setOnClickListener(z->{count.setText(String.valueOf(x));calculatePlan();});row.addView(b);}hs.addView(row);LinearLayout wrap=new LinearLayout(this);wrap.addView(hs,new LinearLayout.LayoutParams(-1,dp(48)));return wrap;}

    private void prepareNewLoan(Client client,Loan source){
        pendingRefinanceLoanId=0;refreshCustomerSelector();clearLoanFields();
        if(client!=null){selectCustomer(client.id);fillClientFields(client);selectedClientId=client.id;}
        if(source!=null){amount.setText(String.valueOf(Math.round(source.principal)));count.setText(String.valueOf(source.installmentCount));rate.setText(trim(source.periodInterest));setSpinnerValue(frequency,source.frequency);installment.setText(String.valueOf(Math.round(source.installment)));due.setText(nextDueDate(source.frequency));moraLoan.setText(trim(source.dailyInterest));graceLoan.setText(String.valueOf(source.graceDays));loanType.setSelection(1);calculatePlan();}
    }

    private void prepareRefinance(Client c,Loan source){
        pendingRefinanceLoanId=source.id;refreshCustomerSelector();selectCustomer(c.id);fillClientFields(c);selectedClientId=c.id;clearLoanFieldsOnly();loanType.setSelection(2);double ref=source.balance+MessageBuilder.interest(source);amount.setText(String.valueOf(Math.round(ref)));count.setText("4");rate.setText("0");setSpinnerValue(frequency,"Semanal");due.setText(LocalDate.now().plusWeeks(1).toString());moraLoan.setText(trim(source.dailyInterest));graceLoan.setText(String.valueOf(source.graceDays));loanNotes.setText("Refinanciación del préstamo #"+source.id);calculatePlan();showPanel(loanPanel);
    }

    private void clearLoanFields(){clearClientFields();clearLoanFieldsOnly();selectedClientId=0;if(customerSelector!=null)customerSelector.setSelection(0);}
    private void clearLoanFieldsOnly(){android.content.SharedPreferences sp=getSharedPreferences("settings",MODE_PRIVATE);amount.setText("");count.setText("4");rate.setText("10");installment.setText("");due.setText(LocalDate.now().plusWeeks(1).toString());moraLoan.setText(trim(sp.getFloat("default_interest",3f)));graceLoan.setText(String.valueOf(sp.getInt("default_grace",3)));loanNotes.setText("");if(frequency!=null)frequency.setSelection(0);if(loanType!=null)loanType.setSelection(0);planPreview.setText("");}
    private void clearClientFields(){if(name==null)return;name.setText("");dni.setText("");phone.setText("");if(clientSms!=null)clientSms.setChecked(false);business.setText("");address.setText("");guarantor.setText("");customerNotes.setText("");}
    private void fillClientFields(Client c){name.setText(c.name);dni.setText(c.dni);phone.setText(c.phone);if(clientSms!=null)clientSms.setChecked(c.smsEnabled);business.setText(c.business);address.setText(c.address);guarantor.setText(c.guarantor);customerNotes.setText(c.notes);}
    private void enableClientFields(boolean enabled){if(name==null)return;name.setEnabled(enabled);dni.setEnabled(enabled);phone.setEnabled(enabled);business.setEnabled(enabled);address.setEnabled(enabled);guarantor.setEnabled(enabled);customerNotes.setEnabled(enabled);if(clientSms!=null)clientSms.setEnabled(enabled);}

    private void refreshCustomerSelector(){
        customerCache=db.getCustomers();List<String> labels=new ArrayList<>();labels.add("+ Nuevo cliente");for(Client c:customerCache)labels.add(c.toString());ArrayAdapter<String> ad=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,labels);customerSelector.setAdapter(ad);
    }
    private void selectCustomer(long id){for(int i=0;i<customerCache.size();i++)if(customerCache.get(i).id==id){customerSelector.setSelection(i+1);return;}}

    private void calculatePlan(){
        double principal=num(amount,0),r=num(rate,0);int n=Math.max(0,(int)num(count,0));if(principal<=0||n<=0){planPreview.setText("Ingresá el monto y la cantidad de cuotas.");return;}double total=principal*(1+(r/100.0)*n);double q=Math.round(total/n);total=q*n;installment.setText(String.valueOf(Math.round(q)));planPreview.setText("Monto: "+MessageBuilder.money(principal)+"\nInterés: "+trim(r)+"% por período × "+n+"\nTotal financiado: "+MessageBuilder.money(total)+"\nCuota: "+MessageBuilder.money(q)+" · "+frequency.getSelectedItem());
    }

    private void saveLoan(){
        try{
            String n=name.getText().toString().trim(),ph=phone.getText().toString().trim();if(n.isEmpty()||ph.isEmpty()){toast("Completá nombre y celular");return;}
            double principal=num(amount,0),q=num(installment,0),r=num(rate,0),mora=num(moraLoan,3);int cnt=(int)num(count,0),grace=Math.max(0,(int)num(graceLoan,3));LocalDate.parse(due.getText().toString().trim());if(principal<=0||q<=0||cnt<=0){toast("Revisá monto, cuotas y valor de cuota");return;}double total=q*cnt;
            long cid=selectedClientId;if(cid<=0)cid=db.addCustomer(n,dni.getText().toString().trim(),ph,business.getText().toString().trim(),address.getText().toString().trim(),guarantor.getText().toString().trim(),customerNotes.getText().toString().trim(),clientSms.isChecked());else db.updateCustomer(cid,n,dni.getText().toString().trim(),ph,business.getText().toString().trim(),address.getText().toString().trim(),guarantor.getText().toString().trim(),customerNotes.getText().toString().trim(),clientSms.isChecked());
            long loanId=db.addLoan(cid,loanType.getSelectedItem().toString().toUpperCase(Locale.ROOT),principal,total,q,cnt,frequency.getSelectedItem().toString(),r,due.getText().toString().trim(),mora,grace,loanNotes.getText().toString().trim());if(loanId>0&&pendingRefinanceLoanId>0)db.markRefinanced(pendingRefinanceLoanId);pendingRefinanceLoanId=0;toast("Préstamo guardado");refreshAll();showPanel(customersPanel);
        }catch(Exception e){toast("Revisá los datos y la fecha");}
    }

    private void refreshAll(){refreshDashboard();refreshCustomerSelector();refreshCollections();refreshCustomers();}
    private void refreshDashboard(){
        List<Loan> loans=db.getActiveLoans();int active=loans.size(),today=0,late=0,promises=0;double capital=0,balance=0,todayAmount=0,lateAmount=0;LocalDate now=LocalDate.now();for(Loan l:loans){capital+=l.principal;balance+=l.balance;if(l.dueDate.equals(now.toString())){today++;todayAmount+=MessageBuilder.currentInstallmentPending(l);}if(MessageBuilder.overdueDays(l)>0){late++;lateAmount+=MessageBuilder.amountDue(l);}if(now.toString().equals(l.commitmentDate))promises++;}
        dashboard.setText("Préstamos activos: "+active+"\nCapital entregado: "+MessageBuilder.money(capital)+"\nSaldo pendiente: "+MessageBuilder.money(balance)+"\n\nVencen hoy: "+today+" · "+MessageBuilder.money(todayAmount)+"\nAtrasados: "+late+" · "+MessageBuilder.money(lateAmount)+"\nCompromisos de hoy: "+promises);
    }

    private void refreshCollections(){
        if(collectionList==null)return;collectionList.removeAllViews();LocalDate now=LocalDate.now();int shown=0;double total=0;for(Loan l:db.getActiveLoans()){
            boolean dueToday=l.dueDate.equals(now.toString()),late=MessageBuilder.overdueDays(l)>0,promise=now.toString().equals(l.commitmentDate),ok;
            if("ATRASADOS".equals(collectionFilter))ok=late;else if("COMPROMISOS".equals(collectionFilter))ok=promise;else if("TODOS".equals(collectionFilter))ok=true;else ok=dueToday||late||promise;
            if(!ok)continue;Client c=db.getCustomer(l.clientId);if(c==null)continue;collectionList.addView(collectionLoanCard(c,l),margins(-1,-2,0,4,0,10));shown++;total+=late?MessageBuilder.amountDue(l):MessageBuilder.currentInstallmentPending(l);
        }
        String title="Cobranza de hoy";if("ATRASADOS".equals(collectionFilter))title="Préstamos atrasados";else if("COMPROMISOS".equals(collectionFilter))title="Compromisos de hoy";else if("TODOS".equals(collectionFilter))title="Todos los préstamos activos";collectionTitle.setText(title+" · "+shown+" · "+MessageBuilder.money(total));if(shown==0)collectionList.addView(text("No hay operaciones en esta vista.",15,Typeface.NORMAL));
    }

    private View collectionLoanCard(Client c,Loan l){
        LinearLayout card=card();TextView h=text(c.name+(c.business.isEmpty()?"":" · "+c.business),17,Typeface.BOLD);h.setTextColor(green);card.addView(h);TextView st=text(loanStatus(l),13,Typeface.BOLD);st.setTextColor(statusColor(l));card.addView(st);String info="Cuota: "+MessageBuilder.money(l.installment)+" · Pendiente actual: "+MessageBuilder.money(MessageBuilder.currentInstallmentPending(l))+"\nVencimiento: "+pretty(l.dueDate)+" · Saldo: "+MessageBuilder.money(l.balance);if(MessageBuilder.overdueDays(l)>0)info+="\nMora: "+MessageBuilder.money(MessageBuilder.interest(l))+" · Total actualizado: "+MessageBuilder.money(MessageBuilder.amountDue(l));if(!l.commitmentDate.isEmpty())info+="\nCompromiso: "+pretty(l.commitmentDate)+(l.commitmentAmount>0?" · "+MessageBuilder.money(l.commitmentAmount):"");card.addView(text(info,14,Typeface.NORMAL),margins(-1,-2,0,6,0,8));LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);Button wa=small("WhatsApp"),pay=small("Pago"),promise=small("Compromiso"),detail=small("Ficha");r.addView(wa,weight44());r.addView(pay,weight44());r.addView(promise,weight44());r.addView(detail,weight44());card.addView(r);wa.setOnClickListener(v->sendWhatsApp(c,l));pay.setOnClickListener(v->askPayment(c,l));promise.setOnClickListener(v->askCommitment(c,l));detail.setOnClickListener(v->showCustomerSheet(c));return card;
    }

    private void refreshCustomers(){
        if(customersList==null)return;customersList.removeAllViews();String f=searchCustomer==null?"":searchCustomer.getText().toString().trim().toLowerCase(Locale.ROOT);int shown=0;for(Client c:db.getCustomers()){String hay=(c.name+" "+c.business+" "+c.dni+" "+c.phone).toLowerCase(Locale.ROOT);if(!f.isEmpty()&&!hay.contains(f))continue;customersList.addView(customerCard(c),margins(-1,-2,0,3,0,10));shown++;}if(shown==0)customersList.addView(text("No se encontraron clientes.",15,Typeface.NORMAL));
    }

    private View customerCard(Client c){
        LinearLayout card=card();TextView h=text(c.name,18,Typeface.BOLD);h.setTextColor(green);card.addView(h);if(!c.business.isEmpty())card.addView(text(c.business,14,Typeface.BOLD));double bal=db.customerBalance(c.id);int loans=db.customerActiveLoans(c.id);String info="DNI: "+dash(c.dni)+" · Celular: "+dash(c.phone)+"\nSMS automático: "+(c.smsEnabled?"Sí":"No")+" · Préstamos activos: "+loans+"\nSaldo total: "+MessageBuilder.money(bal);card.addView(text(info,14,Typeface.NORMAL),margins(-1,-2,0,5,0,7));LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);Button open=small("Abrir ficha"),newLoan=small("Nuevo préstamo"),edit=small("Editar");row.addView(open,weight44());row.addView(newLoan,weight44());row.addView(edit,weight44());card.addView(row);open.setOnClickListener(v->showCustomerSheet(c));newLoan.setOnClickListener(v->{prepareNewLoan(c,null);showPanel(loanPanel);});edit.setOnClickListener(v->editCustomer(c));return card;
    }

    private void showCustomerSheet(Client c){
        ScrollView sv=new ScrollView(this);LinearLayout box=panel();sv.addView(box);TextView head=text(c.name,20,Typeface.BOLD);head.setTextColor(green);box.addView(head);box.addView(text((c.business.isEmpty()?"":c.business+"\n")+"DNI: "+dash(c.dni)+"\nCelular: "+dash(c.phone)+"\nSMS automático: "+(c.smsEnabled?"Sí":"No")+"\nDomicilio: "+dash(c.address)+(c.guarantor.isEmpty()?"":"\nGarante: "+c.guarantor),14,Typeface.NORMAL));box.addView(section("Préstamos"));List<Loan> loans=db.getLoansForCustomer(c.id);if(loans.isEmpty())box.addView(text("Sin préstamos registrados.",14,Typeface.NORMAL));for(Loan l:loans)box.addView(detailLoanCard(c,l),margins(-1,-2,0,3,0,10));new AlertDialog.Builder(this).setView(sv).setNegativeButton("Cerrar",null).setPositiveButton("Nuevo préstamo",(d,w)->{prepareNewLoan(c,null);showPanel(loanPanel);}).show();
    }

    private View detailLoanCard(Client c,Loan l){
        LinearLayout card=card();TextView h=text(l.type+" #"+l.id,16,Typeface.BOLD);h.setTextColor(green);card.addView(h);String info="Estado: "+l.status+" · "+loanStatus(l)+"\nMonto: "+MessageBuilder.money(l.principal)+" · Total financiado: "+MessageBuilder.money(l.totalFinanced)+"\nPlan: "+l.installmentCount+" cuotas "+l.frequency.toLowerCase()+"s de "+MessageBuilder.money(l.installment)+"\nCuotas completas: "+l.paidInstallments+" / "+l.installmentCount+" · Parcial actual: "+MessageBuilder.money(l.currentInstallmentPaid)+"\nSaldo: "+MessageBuilder.money(l.balance)+" · Próximo venc.: "+pretty(l.dueDate)+"\nMora: "+trim(l.dailyInterest)+"% diario · Gracia: "+l.graceDays+" días";if(!l.notes.isEmpty())info+="\nObs.: "+l.notes;card.addView(text(info,13,Typeface.NORMAL));
        Button hist=secondary("Historial de pagos");hist.setOnClickListener(v->showHistory(c,l));card.addView(hist,margins(-1,dp(44),0,4,0,0));if("ACTIVO".equals(l.status)){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);Button pay=small("Pago"),renew=small("Renovar"),refi=small("Refinanciar");r.addView(pay,weight44());r.addView(renew,weight44());r.addView(refi,weight44());card.addView(r);pay.setOnClickListener(v->askPayment(c,l));renew.setOnClickListener(v->{prepareNewLoan(c,l);showPanel(loanPanel);});refi.setOnClickListener(v->prepareRefinance(c,l));}return card;
    }

    private void askPayment(Client c,Loan l){
        LinearLayout box=panel();TextView info=text("Saldo del préstamo: "+MessageBuilder.money(l.balance)+"\nPendiente de cuota: "+MessageBuilder.money(MessageBuilder.currentInstallmentPending(l))+"\nMora calculada hoy: "+MessageBuilder.money(MessageBuilder.interest(l)),14,Typeface.BOLD);box.addView(info);EditText debt=input("Monto aplicado a deuda/cuota",true);debt.setText(String.valueOf(Math.round(MessageBuilder.currentInstallmentPending(l))));EditText mora=input("Mora/interés cobrado (opcional)",true);mora.setText("0");Spinner method=spinner(new String[]{"Efectivo","Transferencia","Mercado Pago","Otro"});EditText note=input("Observación",false);box.addView(debt);box.addView(mora);box.addView(label("Forma de pago"));box.addView(method,margins(-1,dp(48),0,0,0,6));box.addView(note);new AlertDialog.Builder(this).setTitle("Registrar pago · "+c.name).setView(box).setNegativeButton("Cancelar",null).setPositiveButton("Guardar",(d,w)->{double a=num(debt,0),m=num(mora,0);if(a+m<=0){toast("Ingresá un importe");return;}db.registerPayment(l,a,m,method.getSelectedItem().toString(),note.getText().toString().trim());refreshAll();toast("Pago registrado");}).show();
    }

    private void askCommitment(Client c,Loan l){
        LinearLayout box=panel();EditText date=input("Fecha",false);date.setFocusable(false);date.setClickable(true);date.setText(l.commitmentDate.isEmpty()?LocalDate.now().plusDays(1).toString():l.commitmentDate);date.setOnClickListener(v->pickDate(date));EditText val=input("Monto comprometido",true);if(l.commitmentAmount>0)val.setText(String.valueOf(Math.round(l.commitmentAmount)));else val.setText(String.valueOf(Math.round(MessageBuilder.currentInstallmentPending(l))));box.addView(date);box.addView(val);new AlertDialog.Builder(this).setTitle("Compromiso · "+c.name).setView(box).setNegativeButton("Cancelar",null).setPositiveButton("Guardar",(d,w)->{try{LocalDate.parse(date.getText().toString());db.setCommitment(l.id,date.getText().toString(),num(val,0));refreshAll();toast("Compromiso guardado");}catch(Exception e){toast("Fecha inválida");}}).show();
    }

    private void editCustomer(Client c){
        LinearLayout box=panel();EditText n=input("Nombre",false);n.setText(c.name);EditText d=input("DNI",false);d.setText(c.dni);EditText ph=input("Celular",false);ph.setText(c.phone);CheckBox sms=new CheckBox(this);sms.setText("Cliente autoriza recordatorios SMS automáticos");sms.setChecked(c.smsEnabled);EditText b=input("Comercio",false);b.setText(c.business);EditText a=input("Domicilio",false);a.setText(c.address);EditText g=input("Garante",false);g.setText(c.guarantor);EditText no=input("Observaciones",false);no.setText(c.notes);box.addView(n);box.addView(d);box.addView(ph);box.addView(sms);box.addView(b);box.addView(a);box.addView(g);box.addView(no);new AlertDialog.Builder(this).setTitle("Editar cliente").setView(box).setNegativeButton("Cancelar",null).setPositiveButton("Guardar",(x,w)->{if(n.getText().toString().trim().isEmpty()){toast("El nombre es obligatorio");return;}db.updateCustomer(c.id,n.getText().toString().trim(),d.getText().toString().trim(),ph.getText().toString().trim(),b.getText().toString().trim(),a.getText().toString().trim(),g.getText().toString().trim(),no.getText().toString().trim(),sms.isChecked());refreshAll();toast("Cliente actualizado");}).show();
    }

    private void showHistory(Client c,Loan l){List<String> h=db.getPaymentHistory(l.id);List<String> sms=db.getSmsHistory(l.id);StringBuilder s=new StringBuilder();s.append("PAGOS\n");if(h.isEmpty())s.append("Sin pagos registrados.\n");else for(String x:h)s.append("• ").append(x).append("\n\n");s.append("\nSMS AUTOMÁTICOS\n");if(sms.isEmpty())s.append("Sin SMS registrados.");else for(String x:sms)s.append("• ").append(x).append("\n\n");new AlertDialog.Builder(this).setTitle("Historial · "+c.name+" · #"+l.id).setMessage(s.toString()).setPositiveButton("Cerrar",null).show();}
    private void sendWhatsApp(Client c,Loan l){String alias=getSharedPreferences("settings",MODE_PRIVATE).getString("alias","");WhatsAppHelper.open(this,c.phone,MessageBuilder.build(c,l,alias));}

    private String loanStatus(Loan l){LocalDate now=LocalDate.now(),d=LocalDate.parse(l.dueDate);long late=MessageBuilder.overdueDays(l);if(!"ACTIVO".equals(l.status))return l.status;if(late>0)return "ATRASADO "+late+(late==1?" DÍA":" DÍAS");if(d.equals(now))return "VENCE HOY";if(d.isBefore(now)){long remaining=Math.max(0,l.graceDays-java.time.temporal.ChronoUnit.DAYS.between(d,now));return "EN GRACIA · "+remaining+" DÍA"+(remaining==1?"":"S");}return "AL DÍA";}
    private int statusColor(Loan l){if(MessageBuilder.overdueDays(l)>0)return red;LocalDate d=LocalDate.parse(l.dueDate);if(d.isBefore(LocalDate.now())||d.equals(LocalDate.now()))return amber;return green;}

    private void pickDate(EditText target){LocalDate cur;try{cur=LocalDate.parse(target.getText().toString());}catch(Exception e){cur=LocalDate.now();}DatePickerDialog dlg=new DatePickerDialog(this,(v,y,m,d)->target.setText(LocalDate.of(y,m+1,d).toString()),cur.getYear(),cur.getMonthValue()-1,cur.getDayOfMonth());dlg.show();}
    private String nextDueDate(String freq){LocalDate n=LocalDate.now();if("Mensual".equalsIgnoreCase(freq))return n.plusMonths(1).toString();if("Quincenal".equalsIgnoreCase(freq))return n.plusDays(15).toString();return n.plusWeeks(1).toString();}
    private void setSpinnerValue(Spinner sp,String value){for(int i=0;i<sp.getCount();i++)if(sp.getItemAtPosition(i).toString().equalsIgnoreCase(value)){sp.setSelection(i);return;}}

    private void showPanel(LinearLayout p){summaryPanel.setVisibility(p==summaryPanel?View.VISIBLE:View.GONE);collectionPanel.setVisibility(p==collectionPanel?View.VISIBLE:View.GONE);loanPanel.setVisibility(p==loanPanel?View.VISIBLE:View.GONE);customersPanel.setVisibility(p==customersPanel?View.VISIBLE:View.GONE);}
    private LinearLayout panel(){LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);p.setPadding(dp(6),dp(4),dp(6),dp(8));return p;}
    private LinearLayout card(){LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);p.setPadding(dp(12),dp(10),dp(12),dp(10));p.setBackgroundColor(Color.WHITE);return p;}
    private TextView section(String s){TextView t=text(s,20,Typeface.BOLD);t.setTextColor(green);t.setPadding(0,dp(10),0,dp(8));return t;}
    private TextView label(String s){TextView t=text(s,13,Typeface.BOLD);t.setTextColor(Color.DKGRAY);t.setPadding(dp(2),dp(4),0,dp(2));return t;}
    private EditText input(String hint,boolean numeric){EditText e=new EditText(this);e.setHint(hint);e.setTextSize(15);e.setSingleLine(true);e.setPadding(dp(12),dp(8),dp(12),dp(8));e.setBackgroundColor(Color.WHITE);if(numeric)e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);e.setLayoutParams(margins(-1,dp(52),0,0,0,7));return e;}
    private Spinner spinner(String[] a){Spinner s=new Spinner(this);s.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,a));return s;}
    private Button primary(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setBackgroundColor(green);return b;}
    private Button secondary(String s){Button b=new Button(this);b.setText(s);b.setTextColor(green);return b;}
    private Button navButton(String s){Button b=new Button(this);b.setText(s);b.setTextSize(12);b.setTextColor(green);b.setMinWidth(dp(92));return b;}
    private Button chip(String s){Button b=new Button(this);b.setText(s);b.setTextSize(11);b.setTextColor(green);b.setMinHeight(dp(42));return b;}
    private Button small(String s){Button b=new Button(this);b.setText(s);b.setTextSize(10);b.setMinWidth(0);return b;}
    private TextView text(String s,int sp,int style){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTypeface(Typeface.DEFAULT,style);t.setTextColor(Color.rgb(35,35,35));return t;}
    private LinearLayout.LayoutParams weight48(){return new LinearLayout.LayoutParams(0,dp(48),1);}
    private LinearLayout.LayoutParams weight44(){return new LinearLayout.LayoutParams(0,dp(44),1);}
    private LinearLayout.LayoutParams margins(int w,int h,int l,int top,int r,int bot){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.setMargins(dp(l),dp(top),dp(r),dp(bot));return p;}
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density);}
    private double num(EditText e,double fallback){try{return Double.parseDouble(e.getText().toString().trim().replace("$","").replace(".","").replace(",","."));}catch(Exception ex){return fallback;}}
    private String pretty(String iso){try{return MessageBuilder.formatDate(LocalDate.parse(iso));}catch(Exception e){return iso;}}
    private String dash(String s){return s==null||s.trim().isEmpty()?"—":s;}
    private String trim(double x){return x==Math.rint(x)?String.valueOf((int)x):String.format(Locale.US,"%.2f",x);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    private void requestAutomationPermissions(){
        if(checkSelfPermission(Manifest.permission.SEND_SMS)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.SEND_SMS},56);
            return;
        }
        requestExactAlarmAccessIfNeeded();
        updateSmsStatusText();
    }

    private void requestExactAlarmAccessIfNeeded(){
        if(android.os.Build.VERSION.SDK_INT>=android.os.Build.VERSION_CODES.S){
            AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
            if(!am.canScheduleExactAlarms()){
                try{
                    Intent i=new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+getPackageName()));
                    startActivity(i);
                }catch(Exception ignored){}
            }
        }
    }

    private void updateSmsStatusText(){
        if(smsStatus==null)return;
        boolean sms=checkSelfPermission(Manifest.permission.SEND_SMS)==PackageManager.PERMISSION_GRANTED;
        boolean exact=true;
        if(android.os.Build.VERSION.SDK_INT>=android.os.Build.VERSION_CODES.S){
            AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);exact=am.canScheduleExactAlarms();
        }
        boolean enabled=getSharedPreferences("settings",MODE_PRIVATE).getBoolean("sms_auto_enabled",false);
        smsStatus.setText("Automatización: "+(enabled?"ACTIVA":"INACTIVA")+" · Permiso SMS: "+(sms?"OK":"PENDIENTE")+" · Horario: "+(exact?"exacto":"flexible"));
        smsStatus.setTextColor(sms&&enabled?green:(enabled?red:Color.DKGRAY));
    }

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==56){
            if(grantResults.length>0&&grantResults[0]==PackageManager.PERMISSION_GRANTED){
                requestExactAlarmAccessIfNeeded();
                sendBroadcast(new Intent(this,ReminderReceiver.class));
                toast("Permiso SMS autorizado");
            }else{
                new AlertDialog.Builder(this).setTitle("Permiso SMS no disponible")
                        .setMessage("Android no autorizó el envío de SMS. Sin este permiso la app no puede enviar mensajes sola desde el teléfono. La alternativa para automatización total es usar un servidor/proveedor de SMS.")
                        .setPositiveButton("Entendido",null).show();
            }
            updateSmsStatusText();
        }
    }

    private void requestNotifications(){if(android.os.Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},55);}

    private abstract class SimpleWatcher implements android.text.TextWatcher {public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){changed();}public void afterTextChanged(android.text.Editable e){}public abstract void changed();}
}
