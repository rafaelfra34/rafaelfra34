package com.pressfran.cobranzas;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Locale;

public class MessageBuilder {
    private static final DecimalFormat MONEY;
    static {
        DecimalFormatSymbols s=new DecimalFormatSymbols(new Locale("es","AR"));
        s.setGroupingSeparator('.');s.setDecimalSeparator(',');
        MONEY=new DecimalFormat("#,##0",s);
    }

    public static long overdueDays(Loan l){
        if(l==null||l.dueDate==null||l.dueDate.isEmpty())return 0;
        LocalDate due=LocalDate.parse(l.dueDate).plusDays(Math.max(0,l.graceDays));
        long d=ChronoUnit.DAYS.between(due,LocalDate.now());
        return Math.max(0,d);
    }

    public static double currentInstallmentPending(Loan l){
        if(l==null)return 0;
        return Math.max(0,Math.min(l.balance,l.installment-l.currentInstallmentPaid));
    }

    public static double interest(Loan l){return currentInstallmentPending(l)*(l.dailyInterest/100.0)*overdueDays(l);}
    public static double amountDue(Loan l){return currentInstallmentPending(l)+interest(l);}

    public static String build(Client c,Loan l,String alias){ return build(c,l,alias,"PressFran","Te ayudamos a crecer"); }

    public static String build(Client c,Loan l,String alias,String company,String slogan){
        LocalDate today=LocalDate.now();LocalDate due=LocalDate.parse(l.dueDate);long days=overdueDays(l);double mora=interest(l);
        StringBuilder m=new StringBuilder();m.append("Buen día, ").append(c.name).append(".\n\n");
        if(c.business!=null&&!c.business.isEmpty())m.append(c.business).append("\n\n");
        if(l.commitmentDate!=null&&!l.commitmentDate.isEmpty()&&l.commitmentDate.equals(today.toString())){
            m.append("Para hoy tenemos registrado tu compromiso de pago");
            if(l.commitmentAmount>0)m.append(" por ").append(money(l.commitmentAmount));
            m.append(".\n\n");
        }
        if(today.isBefore(due)){
            m.append("Te recordamos que tu próxima cuota vence el ").append(formatDate(due)).append(".\n");
            m.append("Importe pendiente de la cuota: ").append(money(currentInstallmentPending(l))).append("\n");
        }else if(today.equals(due)||days==0){
            m.append("Tu cuota se encuentra dentro de la fecha de vencimiento/gracia.\n");
            m.append("Importe pendiente de la cuota: ").append(money(currentInstallmentPending(l))).append("\n");
        }else{
            m.append("Tu cuota registra ").append(days).append(days==1?" día":" días").append(" de mora luego del período de gracia.\n");
            m.append("Cuota pendiente: ").append(money(currentInstallmentPending(l))).append("\n");
            m.append("Interés por mora (").append(trim(l.dailyInterest)).append("% diario): ").append(money(mora)).append("\n");
            m.append("Total actualizado: ").append(money(amountDue(l))).append("\n");
        }
        m.append("Saldo total del préstamo: ").append(money(l.balance)).append("\n");
        m.append("Plan: ").append(l.installmentCount).append(" cuotas ").append(l.frequency.toLowerCase()).append("s de ").append(money(l.installment)).append("\n");
        if(alias!=null&&!alias.trim().isEmpty())m.append("\nAlias para transferencia: *").append(alias.trim()).append("*\n");
        m.append("\nUna vez realizado el pago, envianos el comprobante.\n\n");
        String brand=(company==null||company.trim().isEmpty())?"PressFran":company.trim();
        m.append("*").append(brand).append("*");
        if(slogan!=null&&!slogan.trim().isEmpty())m.append("\n_").append(slogan.trim()).append("_");
        return m.toString();
    }


    public static String buildSms(Client c, Loan l, String alias, String eventType){ return buildSms(c,l,alias,eventType,"PressFran"); }

    public static String buildSms(Client c, Loan l, String alias, String eventType, String company){
        long days=overdueDays(l);
        StringBuilder m=new StringBuilder();
        String brand=(company==null||company.trim().isEmpty())?"PressFran":company.trim();
        m.append(brand).append(": Hola ").append(c.name).append(". ");
        if("PREVIO".equals(eventType)){
            m.append("Te recordamos que mañana vence tu cuota de ").append(money(currentInstallmentPending(l))).append(".");
        }else if("VENCIMIENTO".equals(eventType)){
            m.append("Hoy vence tu cuota de ").append(money(currentInstallmentPending(l))).append(".");
        }else if("COMPROMISO".equals(eventType)){
            m.append("Hoy tenemos registrado tu compromiso de pago");
            if(l.commitmentAmount>0)m.append(" por ").append(money(l.commitmentAmount));
            m.append(".");
        }else if("MORA".equals(eventType)){
            m.append("Tu cuota registra ").append(days).append(days==1?" día":" días")
                    .append(" de mora. Cuota ").append(money(currentInstallmentPending(l)))
                    .append(", interés ").append(money(interest(l)))
                    .append(", total actualizado ").append(money(amountDue(l))).append(".");
        }else{
            m.append("Recordatorio de tu cuota: ").append(money(currentInstallmentPending(l))).append(".");
        }
        if(alias!=null&&!alias.trim().isEmpty())m.append(" Alias: ").append(alias.trim()).append(".");
        m.append(" Si ya pagaste, desestimá este aviso. ").append(brand).append(".");
        return m.toString();
    }

    public static String money(double v){synchronized(MONEY){return "$ "+MONEY.format(Math.round(v));}}
    public static String formatDate(LocalDate d){return String.format("%02d/%02d/%04d",d.getDayOfMonth(),d.getMonthValue(),d.getYear());}
    private static String trim(double x){return x==Math.rint(x)?String.valueOf((int)x):String.valueOf(x);}
}
